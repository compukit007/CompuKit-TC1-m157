# Generates tc1_lang.h: all TC1 UI strings for Dutch, English and Russian.
# Russian strings are written as octal escapes in Windows-1251 so the
# C source is plain ASCII and independent of the file encoding.
param([string]$Out)

$names = @(
 'TC1_TxtTesting','TC1_TxtVbat','TC1_TxtNoBat','TC1_TxtDiode','TC1_TxtCap',
 'TC1_TxtRes','TC1_Txt2Res','TC1_TxtCoil','TC1_TxtESR','TC1_TxtLeak',
 'TC1_TxtNo1','TC1_TxtNo2','TC1_TxtIR','TC1_TxtUser','TC1_TxtData',
 'TC1_TxtSamsung','TC1_TxtNEC','TC1_TxtShort1','TC1_TxtShort2',
 'TC1_TxtOpen1','TC1_TxtOpen2','TC1_TxtZener','TC1_TxtZenerHint',
 'TC1_TxtESRTitle','TC1_TxtESRWarn1','TC1_TxtESRWarn2','TC1_TxtESRWarn3',
 'TC1_TxtESRPins','TC1_TxtVoltage',
 'TC1_TxtMenu1','TC1_TxtMenu2','TC1_TxtMenu3','TC1_TxtMenu4','TC1_TxtMenu5',
 'TC1_TxtMenu6','TC1_TxtHint1',
 'TC1_TxtName','TC1_TxtBase','TC1_TxtAuthor','TC1_TxtStartHint'
)

$nl = @(
 'Testen...','Vbat=','geen accu','Diode','Condensator',
 'Weerstand','2 weerstanden','Spoel','ESR=','Ilek=',
 'Onbekend of','defect onderdeel','IR-decoder','Adres','Commando',
 'Samsung','NEC','Verbind pin','1, 2 en 3',
 'Verwijder de','verbinding','Zenertest','2x kort=terug',
 'ESR-meting','Print uit en','condensator','eerst ontladen!',
 'pin1=+  pin3=-','Spanning!',
 'Kalibratie','Zenertest','ESR-meting','Opto-test','Uitzetten',
 'Terug','lang = kiezen',
 'Compukit','m-firmware 1.57','door M. Reschke','1x kort=start'
)

$en = @(
 'Testing...','Vbat=','no battery','Diode','Capacitor',
 'Resistor','2 resistors','Inductor','ESR=','Ileak=',
 'Unknown or','damaged part','IR decoder','UserCode','DataCode',
 'Samsung','NEC','Connect pins','1, 2 and 3',
 'Remove the','connection','Zener test','2x short=back',
 'ESR meter','Power off and','discharge the','capacitor first',
 'pin1=+  pin3=-','Voltage!',
 'Calibration','Zener test','ESR meter','Opto test','Power off',
 'Back','long = select',
 'Compukit','m-firmware 1.57','by M. Reschke','1x short=start'
)

$ru = @(
 'Тест...','Vbat=','нет батареи','Диод','Конденсатор',
 'Резистор','2 резистора','Катушка','ESR=','Iут=',
 'Неизвестная или','неисправная деталь','ИК-декодер','Адрес','Команда',
 'Samsung','NEC','Соедините выводы','1, 2 и 3',
 'Уберите','перемычку','Стабилитрон','2x кратко=назад',
 'Измерение ESR','Выключите плату','и разрядите','конденсатор!',
 'pin1=+  pin3=-','Напряжение!',
 'Калибровка','Стабилитрон','Измерение ESR','Оптопара','Выключить',
 'Назад','долго = выбор',
 'Compukit','m-firmware 1.57','автор M. Reschke','1x кратко=старт'
)

$cp1251 = [Text.Encoding]::GetEncoding(1251)

function CStr([string]$s, [bool]$octal) {
  if (-not $octal) { return '"' + $s.Replace('\','\\').Replace('"','\"') + '"' }
  $sb = New-Object Text.StringBuilder
  [void]$sb.Append('"')
  foreach ($b in $cp1251.GetBytes($s)) {
    if ($b -ge 0x20 -and $b -lt 0x7f -and $b -ne 0x22 -and $b -ne 0x5c) {
      [void]$sb.Append([char]$b)
    } else {
      [void]$sb.Append('\' + [Convert]::ToString($b, 8).PadLeft(3,'0'))
    }
  }
  [void]$sb.Append('"')
  return $sb.ToString()
}

function Block($list, [bool]$octal, [string]$lang) {
  $lines = @()
  for ($i = 0; $i -lt $names.Count; $i++) {
    $txt = $list[$i]
    $lines += ('  const unsigned char {0}[] PROGMEM = {1};   /* {2} */' -f $names[$i], (CStr $txt $octal), $(if ($octal) { $lang + ': ' + $i } else { $txt }))
  }
  return $lines
}

$h = @()
$h += '/* ************************************************************************'
$h += ' *'
$h += ' *   TC1 user interface strings (Compukit)'
$h += ' *   - Dutch (default), English (TC1_LANG_EN), Russian (TC1_LANG_RU)'
$h += ' *   - Russian: Windows-1251, written as octal escapes'
$h += ' *   - generated, include only once (tc1_ui.c)'
$h += ' *'
$h += ' * ************************************************************************ */'
$h += ''
$h += '#if defined (TC1_LANG_EN)'
$h += Block $en $false 'en'
$h += '#elif defined (TC1_LANG_RU)'
$h += Block $ru $true 'ru'
$h += '#else'
$h += Block $nl $false 'nl'
$h += '#endif'
$h += ''

[IO.File]::WriteAllText($Out, ($h -join "`r`n"), [Text.Encoding]::ASCII)

# report maximum lengths
for ($i = 0; $i -lt $names.Count; $i++) {
  $m = [Math]::Max([Math]::Max($nl[$i].Length, $en[$i].Length), $ru[$i].Length)
  if ($m -gt 16) { "{0}: nl {1} / en {2} / ru {3}" -f $names[$i], $nl[$i].Length, $en[$i].Length, $ru[$i].Length }
}
